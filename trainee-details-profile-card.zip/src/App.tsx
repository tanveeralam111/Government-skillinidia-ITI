/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Printer, CheckCircle, Edit3, RefreshCw, Menu, ChevronRight } from 'lucide-react';

interface TraineeData {
  rollNo: string;
  fatherName: string;
  tradeName: string;
  dob: string;
  itiName: string;
  name: string;
  tradeCode: string;
  admissionYear: string;
  itiCode: string;
  itiAddress: string;
  shift: string;
  trainingDuration: string;
  certificateIssueDate: string;
  unit: string;
  certified: string;
  avatarUrl: string;
}

export default function App() {
  const initialData: TraineeData = {
    rollNo: 'R180850001819',
    fatherName: 'Sameer Raza',
    tradeName: 'Refrigeration and Air-Conditioning',
    dob: '01-March-2003',
    itiName: 'Siddharth Private ITI, Dhanbad',
    name: 'Ahmad Raza',
    tradeCode: '998',
    admissionYear: '2020',
    itiCode: 'PR20000164',
    itiAddress: 'P.O. B. Polytechnic, Dhanbad DHANBAD Jharkhand PIN 828130',
    shift: '1',
    trainingDuration: '--',
    certificateIssueDate: '11-Nov-2022',
    unit: '1',
    certified: 'Yes',
    avatarUrl: '/assets/aistudio/IMG-20261113-WA0023_95f7c9df.jpg',
  };

  const [data, setData] = useState<TraineeData>(initialData);
  const [isEditing, setIsEditing] = useState(false);
  const [tempData, setTempData] = useState<TraineeData>(initialData);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    setData(tempData);
    setIsEditing(false);
  };

  const handleReset = () => {
    setData(initialData);
    setTempData(initialData);
  };

  return (
    <div className="min-h-screen bg-[#f5f6f8] font-['Inter',sans-serif] text-[#333333] flex flex-col justify-between">
      <div>
        {/* Top Announcement Ticker Banner */}
        <div className="bg-[#fff3eb] text-center py-2 px-4 border-b border-orange-200 print:hidden">
          <a
            href="#result"
            onClick={(e) => e.preventDefault()}
            className="text-xs sm:text-sm font-semibold text-[#d97706] hover:underline inline-flex items-center space-x-1"
          >
            <span>Click here to view CTS AITT Mains Examination-2026 Result</span>
            <ChevronRight className="w-4 h-4" />
          </a>
        </div>

        {/* Official Header Bar */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-xs print:hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
            {/* Left: Hamburger & Logos */}
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-gray-700 hover:text-gray-900 rounded-md focus:outline-none"
                aria-label="Menu"
              >
                <Menu className="w-6 h-6" />
              </button>

              <div className="flex items-center space-x-3 sm:space-x-4">
                {/* Emblem / Govt Logo placeholder representation */}
                <div className="flex items-center space-x-1.5">
                  <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center font-bold text-orange-800 text-xs border border-orange-300">
                    🏛️
                  </div>
                  <div className="hidden sm:block text-[10px] leading-tight text-gray-700 font-medium">
                    <div>MINISTRY OF SKILL DEVELOPMENT</div>
                    <div>AND ENTREPRENEURSHIP</div>
                  </div>
                </div>

                <div className="h-6 w-[1px] bg-gray-200 hidden sm:block"></div>

                {/* Skill India Logo text */}
                <div className="font-bold text-sm tracking-tight text-slate-800 flex items-center space-x-1">
                  <span className="text-blue-700 font-extrabold">Skill</span>
                  <span className="text-orange-600 font-extrabold">India</span>
                </div>

                <div className="h-6 w-[1px] bg-gray-200 hidden md:block"></div>

                {/* ITI Brand Badge */}
                <div className="flex items-center space-x-1 bg-slate-900 text-white px-2 py-1 rounded text-xs font-bold tracking-wider">
                  <span className="text-orange-400">I</span>
                  <span className="text-green-400">T</span>
                  <span className="text-blue-400">I</span>
                </div>
              </div>
            </div>

            {/* Right Action Buttons */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              <button
                onClick={() => alert('Result Portal view')}
                className="hidden md:inline-flex items-center px-4 py-1.5 border border-orange-300 text-orange-800 bg-[#fff8f5] hover:bg-orange-100 text-xs font-semibold rounded-full transition shadow-2xs"
              >
                RESULT
              </button>

              <button
                onClick={() => alert('Instructor self registration on NIMS')}
                className="hidden lg:inline-flex items-center px-4 py-1.5 border border-orange-300 text-orange-800 bg-[#fff8f5] hover:bg-orange-100 text-xs font-semibold rounded-full transition shadow-2xs"
              >
                Instructor self registration on NIMS
              </button>

              <button
                onClick={() => alert('Login portal')}
                className="inline-flex items-center px-5 py-2 bg-[#e67e22] hover:bg-[#d35400] text-white text-xs font-bold rounded-md shadow-sm transition"
              >
                LOGIN
              </button>
            </div>
          </div>

          {/* Mobile dropdown menu if toggled */}
          {mobileMenuOpen && (
            <div className="bg-white border-t border-gray-100 px-4 py-3 space-y-2 md:hidden">
              <button
                onClick={() => { alert('Result Portal view'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-xs font-semibold text-orange-800 bg-orange-50 rounded"
              >
                RESULT
              </button>
              <button
                onClick={() => { alert('Instructor self registration on NIMS'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-xs font-semibold text-orange-800 bg-orange-50 rounded"
              >
                Instructor self registration on NIMS
              </button>
            </div>
          )}
        </header>

        {/* Main Content Area: Trainee Details Card */}
        <div className="py-8 px-4 sm:px-6 flex flex-col items-center">
          {/* Action toolbar for card */}
          <div className="w-full max-w-[800px] mb-4 flex items-center justify-between print:hidden">
            <div className="text-xs font-medium text-gray-500 uppercase tracking-wider">
              Trainee Profile & Verification Portal
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  setTempData(data);
                  setIsEditing(!isEditing);
                }}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-white border border-gray-300 text-gray-700 text-xs font-medium rounded-md shadow-sm hover:bg-gray-50 transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{isEditing ? 'Cancel Edit' : 'Edit Details'}</span>
              </button>
              <button
                onClick={handlePrint}
                className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 bg-[#111111] text-white text-xs font-medium rounded-md shadow-sm hover:bg-gray-800 transition"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / Save PDF</span>
              </button>
            </div>
          </div>

          {/* Main Card Container */}
          <div className="w-full max-w-[800px] bg-[#ffffff] rounded-[10px] shadow-[0_4px_20px_rgba(0,0,0,0.06)] border border-gray-100 overflow-hidden mb-8">
            {/* Top Card Header */}
            <div className="px-6 py-4 border-b border-[#eeeeee]">
              <h2 className="text-[22px] font-bold text-[#111111] tracking-tight">Trainee Details</h2>
            </div>

            {/* Card Body */}
            <div className="p-6 sm:p-8">
              {/* Profile Photo Section */}
              <div className="flex flex-col items-center justify-center mb-8">
                <div className="relative">
                  <img
                    src={data.avatarUrl}
                    alt={data.name}
                    className="w-[100px] h-[100px] rounded-full object-cover border-[3px] border-[#c59b6d] shadow-sm bg-gray-100"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  <div className="absolute bottom-0 right-0 bg-emerald-600 text-white p-1 rounded-full border-2 border-white shadow" title="Verified Trainee">
                    <CheckCircle className="w-3.5 h-3.5" />
                  </div>
                </div>
                <span className="mt-2 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  Verified Record
                </span>
              </div>

              {/* Edit Form or Display View */}
              {isEditing ? (
                <form onSubmit={handleSaveEdit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-10 gap-y-4">
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Roll No</label>
                      <input
                        type="text"
                        value={tempData.rollNo}
                        onChange={(e) => setTempData({ ...tempData, rollNo: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Name</label>
                      <input
                        type="text"
                        value={tempData.name}
                        onChange={(e) => setTempData({ ...tempData, name: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Father Name</label>
                      <input
                        type="text"
                        value={tempData.fatherName}
                        onChange={(e) => setTempData({ ...tempData, fatherName: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Trade Code</label>
                      <input
                        type="text"
                        value={tempData.tradeCode}
                        onChange={(e) => setTempData({ ...tempData, tradeCode: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Trade Name</label>
                      <input
                        type="text"
                        value={tempData.tradeName}
                        onChange={(e) => setTempData({ ...tempData, tradeName: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Admission Year</label>
                      <input
                        type="text"
                        value={tempData.admissionYear}
                        onChange={(e) => setTempData({ ...tempData, admissionYear: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Date of Birth</label>
                      <input
                        type="text"
                        value={tempData.dob}
                        onChange={(e) => setTempData({ ...tempData, dob: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">ITI Code</label>
                      <input
                        type="text"
                        value={tempData.itiCode}
                        onChange={(e) => setTempData({ ...tempData, itiCode: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">ITI Name</label>
                      <input
                        type="text"
                        value={tempData.itiName}
                        onChange={(e) => setTempData({ ...tempData, itiName: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">ITI Address</label>
                      <textarea
                        value={tempData.itiAddress}
                        onChange={(e) => setTempData({ ...tempData, itiAddress: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none resize-none h-16"
                        required
                      />
                    </div>
                  </div>

                  {/* Bottom Section Edit */}
                  <div className="pt-6 border-t border-[#eeeeee] grid grid-cols-1 sm:grid-cols-2 gap-x-10 gap-y-4">
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Shift</label>
                      <input
                        type="text"
                        value={tempData.shift}
                        onChange={(e) => setTempData({ ...tempData, shift: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Unit</label>
                      <input
                        type="text"
                        value={tempData.unit}
                        onChange={(e) => setTempData({ ...tempData, unit: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Training Duration</label>
                      <input
                        type="text"
                        value={tempData.trainingDuration}
                        onChange={(e) => setTempData({ ...tempData, trainingDuration: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Certified</label>
                      <input
                        type="text"
                        value={tempData.certified}
                        onChange={(e) => setTempData({ ...tempData, certified: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#111111] mb-1">Certificate Issue Date</label>
                      <input
                        type="text"
                        value={tempData.certificateIssueDate}
                        onChange={(e) => setTempData({ ...tempData, certificateIssueDate: e.target.value })}
                        className="w-full text-sm p-2 border border-gray-300 rounded focus:ring-2 focus:ring-[#c59b6d] outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={handleReset}
                      className="px-4 py-2 text-xs font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded transition flex items-center space-x-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Reset Default</span>
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 text-xs font-semibold text-white bg-[#111111] hover:bg-gray-800 rounded transition shadow-sm"
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-6">
                  {/* Top Section Grid (2 Columns, 150px label width or equivalent subgrid alignment) */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-[40px] gap-y-[14px]">
                    {/* Left Column - Top Section */}
                    <div className="space-y-[14px]">
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Roll No</span>
                        <span className="font-normal text-[#333333] text-sm">{data.rollNo}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Father Name</span>
                        <span className="font-normal text-[#333333] text-sm">{data.fatherName}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Trade Name</span>
                        <span className="font-normal text-[#333333] text-sm">{data.tradeName}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Date of Birth</span>
                        <span className="font-normal text-[#333333] text-sm">{data.dob}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">ITI Name</span>
                        <span className="font-normal text-[#333333] text-sm">{data.itiName}</span>
                      </div>
                    </div>

                    {/* Right Column - Top Section */}
                    <div className="space-y-[14px]">
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Name</span>
                        <span className="font-normal text-[#333333] text-sm">{data.name}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Trade Code</span>
                        <span className="font-normal text-[#333333] text-sm">{data.tradeCode}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Admission Year</span>
                        <span className="font-normal text-[#333333] text-sm">{data.admissionYear}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">ITI Code</span>
                        <span className="font-normal text-[#333333] text-sm">{data.itiCode}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">ITI Address</span>
                        <span className="font-normal text-[#333333] text-sm leading-relaxed">{data.itiAddress}</span>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Section (Separated by 24px top margin, following same 2-column alignment) */}
                  <div className="mt-[24px] pt-[24px] border-t border-[#eeeeee] grid grid-cols-1 md:grid-cols-2 gap-x-[40px] gap-y-[14px]">
                    {/* Left Column - Bottom Section */}
                    <div className="space-y-[14px]">
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Shift</span>
                        <span className="font-normal text-[#333333] text-sm">{data.shift}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Training Duration</span>
                        <span className="font-normal text-[#333333] text-sm">{data.trainingDuration}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Certificate issue date</span>
                        <span className="font-normal text-[#333333] text-sm">{data.certificateIssueDate}</span>
                      </div>
                    </div>

                    {/* Right Column - Bottom Section */}
                    <div className="space-y-[14px]">
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Unit</span>
                        <span className="font-normal text-[#333333] text-sm">{data.unit}</span>
                      </div>
                      <div className="grid grid-cols-[150px_1fr] items-start">
                        <span className="font-bold text-[#111111] text-sm">Certified</span>
                        <span className="font-normal text-[#333333] text-sm font-semibold text-emerald-700">{data.certified}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-6 text-center text-xs text-gray-500 print:hidden mt-auto">
        <p className="mb-1">National Council for Vocational Training (NCVT) • Ministry of Skill Development and Entrepreneurship</p>
        <p className="text-gray-400">Official Portal Version 2026. All rights reserved.</p>
      </footer>
    </div>
  );
}
